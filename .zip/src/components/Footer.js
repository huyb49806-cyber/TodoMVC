import React from 'react';  //để sử dụng JSX và React.Component


class Footer extends React.Component {      //tạo class F kế thừa từ R.C
    render() {
        const {onClearCompleted } = this.props; //destructor phân rã các thuộc tính cảu object thành biến
        return (
            <div className="footer">
                <div className="filters">
                </div>
                <div>
                    <button>Clear completed</button>
                </div>
            </div>
        );
    }
}


export default Footer;