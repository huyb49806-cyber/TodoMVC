import React from 'react';

class toDoInput extends React.Component {
    constructor(props){
        super(props);
        this.state = { text: '' };      //khởi tạo state trong ô input
    }
    render() {
        return(
            <form>
                <input
                    type="text"
                    placeholder="Điều gì cần được hoàn thành?"
                    value={this.state.text}
                    autoFocus               //tự động đặt con trỏ chuột vào ô input khi C render lần đầu
                />
            </form>
        );
    }
}

export default toDoInput;