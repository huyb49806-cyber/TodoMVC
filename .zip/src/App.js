import React from 'react';
import TodoInput from './components/TodoInput';
import TodoList from './components/TodoList';
import Footer from './components/Footer';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      todos: []   //mảng công vc
    };
  }
 
  render() {
    const { todos } = this.state;

    return (
      <div className="app">
        <h1>todos</h1>
        <div className="main">
          <TodoInput/>
          <TodoList
            
          />
          <Footer
            todos={todos}
          />
        </div>
      </div>
    );
  }
}

export default App;