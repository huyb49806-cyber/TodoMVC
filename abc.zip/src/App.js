
import './App.css';
import Header from './components/Header';
import MainContent from './components/MainContent';
import NavigationMenu from './components/NavigationMenu';
import Content from './components/Content';
import Footer from './components/Footer';


function App() {
  return (
    <>
      <Header />
      <NavigationMenu />
      <div className="main">
        <Content />
        <MainContent />
        <Content />
      </div>
      <Footer />
    </>
  );
}

export default App;
