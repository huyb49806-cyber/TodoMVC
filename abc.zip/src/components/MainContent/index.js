function MainContent() {
    return (
        <>
            <div className="box">MainContent</div>
        </>
    )
}

export default MainContent;