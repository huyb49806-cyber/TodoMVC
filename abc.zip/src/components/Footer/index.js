function Footer() {
    return (
        <>
            <div className="box">Footer</div>
        </>
    )
}

export default Footer;