function Content() {
    return (
        <>
            <div className="box">Content</div>
        </>
    )
}

export default Content;