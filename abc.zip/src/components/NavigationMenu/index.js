function NavigationMenu() {
    return (
        <>
            <div className="box">NavigationMenu</div>
        </>
    )
}

export default NavigationMenu;