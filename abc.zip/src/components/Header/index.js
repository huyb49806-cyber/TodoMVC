function Header() {
    return (
        <>
            <div className="box">Header</div>
        </>
    )
}

export default Header;